﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RouletteWebApi.DataObjects.RequestObjects
{
   public class PayoutRequestDTO
    {
        public string BetReference { get; set; }
    }
}
