﻿namespace RouletteWebApi.DataObjects.Enums
{
    public enum BetDataType
    {
        Integer,
        Long,
        Double,
        String,
        Bool,
        Decimal
    }
}
