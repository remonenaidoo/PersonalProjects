﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RouletteWebApi.DataObjects.Enums
{
    public enum TransactionTypes
    {
        StrikeBet = 1,
        ResultBet
    }
}
