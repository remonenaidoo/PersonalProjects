﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using RouletteWebApi.DataObjects.Constants;
using RouletteWebApi.DataObjects.DataObjects;
using RouletteWebApi.DataObjects.ResponseObjects;
using RouletteWebApi.LogicLayer.Helpers.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace RouletteWebApi.LogicLayer.Helpers
{
    public class BetHelper : IBetHelper
    {
        private readonly BetOptions _BetOptions; private readonly ITokenHelper _tokenHelper; private readonly IConfiguration _config;

        public BetHelper(ITokenHelper tokenHelper, IConfiguration configuration)
        {
            _BetOptions = new BetOptions();
            _tokenHelper = tokenHelper;
            _config = configuration;
        }

        public async Task<string> ReturnBetColour(int RouletteNumber)
        {
            return _BetOptions.NumbersBlack.Contains(RouletteNumber) ? BetColours.Black : 
                _BetOptions.NumbersRed.Contains(RouletteNumber) ? BetColours.Red : BetColours.Green;

        }
        public async Task<string> ReturnBetParity(int RouletteNumber)
        {
            return RouletteNumber % 2 == 0 ? BetParity.Even : BetParity.Odd;
        }
        public async Task<string> ReturnBetRange(int RouletteNumber)
        {
           return _BetOptions.MinBet >= RouletteNumber && _BetOptions.MidBet <= RouletteNumber ?
                BetRange.Low : BetRange.High;
        }

        public async Task<PayoutDTO> ReturnBetResult(InitialBetDTO originalBet, SpinResponseDTO spins)
        {
            PayoutDTO payoutResult = new() { IsSuccess = false, PayoutRate = PayoutRates.Default };

            Dictionary<string, int> betOutcomeToPayoutRate = new()
            {
                { spins.Parity, PayoutRates.Parity },
                { spins.Colour, PayoutRates.ColourRedBlack },
                { spins.BetRange, PayoutRates.Range },
                { spins.Number.ToString(), PayoutRates.Number },
                { "0", PayoutRates.ColurGreen }
            };

            if (betOutcomeToPayoutRate.TryGetValue(originalBet.Bet, out var payoutRate))
            {
                payoutResult.IsSuccess = true;
                payoutResult.PayoutRate = payoutRate;

                return payoutResult;
            }
            else
            {
                payoutResult.IsSuccess = false;
                payoutResult.PayoutRate = PayoutRates.Default;

                return payoutResult;
            }
        }

        public async Task<string> ReturnUserFromHeaderToken(IHeaderDictionary headerDictionary)
        {
            headerDictionary.TryGetValue("Authorization", out StringValues authorization);

            if (StringValues.IsNullOrEmpty(authorization))
                return string.Empty;

            var claimsPrinciple = await _tokenHelper.GetValueFromToken(authorization, _config["Jwt:Key"]);

            if (claimsPrinciple == null)
                return string.Empty;

            var simplePrinciple = claimsPrinciple.Identity as ClaimsIdentity;
            var jwtPunterId = simplePrinciple.Name;

            return jwtPunterId;
        }
    }
}
