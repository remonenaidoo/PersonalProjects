﻿using FluentValidation;
using WebApi.Models.RequestObjects;

namespace WebApi.Logic.FluentValidation
{
    public class AuthenticateUserValidator : AbstractValidator<LoginUserRequestDTO>
    {
        public AuthenticateUserValidator()
        {
            RuleFor(x => x.EmailAddress).EmailAddress()
                .NotEmpty().WithMessage("Email is required to authenticate user");

            RuleFor(x => x.Password).NotEmpty().WithMessage("Password is required to authenticate user");
        }
    }
}
