﻿namespace WebApi.Logic.Logging.Interfaces
{
    public interface ILoggerHelper
    {
        void LogInfo(string Message);
        void LogError(string Message);
        void LogDebug(string Message);
    }
}
