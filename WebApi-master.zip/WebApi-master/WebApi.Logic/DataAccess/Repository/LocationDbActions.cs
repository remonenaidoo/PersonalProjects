﻿using Dapper;
using System.Data;
using WebApi.Logic.DataAccess.Database.Interfaces;
using WebApi.Logic.DataAccess.Repository.Interfaces;
using WebApi.Logic.DataAccess.ResourceFile;
using WebApi.Models.DataObjects;
using WebApi.Models.RequestObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Logic.DataAccess.Repository
{
    public class LocationDbActions : ILocationDbActions
    {
        private readonly IDbContext _context;
        public LocationDbActions(IDbContext context)
        {
            _context = context;
        }

        public async Task<List<CitiesDTO>> GetCitiesbyProvince(int? ProvinceID)
        {
            using var connection = _context.CreateConnection();

            var cities = await connection.QueryAsync<CitiesDTO>(SQLResources.GetCitiesForProvince, new { ProvinceID },
                commandType: CommandType.StoredProcedure);

            return cities.ToList();
        }

        public async Task<List<ProvincesDTO>> GetProvinces()
        {
            using var connection = _context.CreateConnection();

            var provinces =  await connection.QueryAsync<ProvincesDTO>(SQLResources.GetProvinces,null,
                commandType: CommandType.StoredProcedure);

            return provinces.ToList();
        }

        public async Task<string> GetLocationDataPerAUser()
        {
            using var connection = _context.CreateConnection();

            var jsonResults = await connection.QueryFirstOrDefaultAsync<string>(SQLResources.LocationDataPerUsers, null,
                commandType: CommandType.StoredProcedure);

            return jsonResults;
        }

        public async Task<List<GetClientsByLocationResponseDTO>> GetClientsBySelectedLocation(GetClientsByLocationRequestDTO SelectedLocation)
        {
            using var connection = _context.CreateConnection();

            var clients = await connection.QueryAsync<GetClientsByLocationResponseDTO>(SQLResources.GetClientDetailsBySelectedLocation, 
                new { SelectedLocation.LocationType, SelectedLocation.ID}, commandType: CommandType.StoredProcedure);

            return clients.ToList();
        }

        public async Task<List<GetRegisteredClientsDTO>> GetRegisteredClients()
        {
            using var connection = _context.CreateConnection();

            var clients = await connection.QueryAsync<GetRegisteredClientsDTO>(SQLResources.GetRegisteredClients,
                new { }, commandType: CommandType.StoredProcedure);

            return clients.ToList();
        }
    }
}
