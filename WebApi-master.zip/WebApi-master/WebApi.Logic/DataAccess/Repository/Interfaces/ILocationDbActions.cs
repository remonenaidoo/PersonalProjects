﻿using WebApi.Models.DataObjects;
using WebApi.Models.RequestObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Logic.DataAccess.Repository.Interfaces
{
    public interface ILocationDbActions
    {
        Task<List<CitiesDTO>> GetCitiesbyProvince(int? ProvinceID);
        Task<List<ProvincesDTO>> GetProvinces();
        Task<string> GetLocationDataPerAUser();
        Task<List<GetClientsByLocationResponseDTO>> GetClientsBySelectedLocation(GetClientsByLocationRequestDTO SelectedLocation);
        Task<List<GetRegisteredClientsDTO>> GetRegisteredClients();

    }
}
