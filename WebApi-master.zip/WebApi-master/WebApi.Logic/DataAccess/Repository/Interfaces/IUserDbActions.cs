﻿using WebApi.Models.DataObjects;
using WebApi.Models.RequestObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Logic.DataAccess.Repository.Interfaces
{
    public interface IUserDbActions
    {
        Task<ClientResponseDTO> CreateUser(AddClientRequestDTO UserInfo);
        Task<ClientResponseDTO> LoginUser(LoginUserRequestDTO UserInfo);
        Task<GetProfileDetailsByClientDTO> GetProfileDetailsByClientID(Guid ClientID);
        Task InsertClientFileLocations(List<ClientFileLocationDTO> clientFileLocations);
        Task DeleteFileLocationPerClient(Guid ClientID);
        Task<List<ClientFileLocationDTO>> GetImageLocationPerUser(Guid ClientID);
        Task<List<ClientFileLocationDTO>> GetClientProfilePicturePath();
    }
}
