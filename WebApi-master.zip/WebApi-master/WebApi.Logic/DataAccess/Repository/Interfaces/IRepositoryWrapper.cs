﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Logic.DataAccess.Repository.Interfaces
{
   public interface IRepositoryWrapper
    {
        IUserDbActions UserDbActions { get; }
        ILocationDbActions locationDbActions { get; }
    }
}
