﻿using WebApi.Logic.DataAccess.Database.Interfaces;
using WebApi.Logic.DataAccess.Repository.Interfaces;

namespace WebApi.Logic.DataAccess.Repository
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private IDbContext _context;
        public UserDbActions _userDbActions;
        public LocationDbActions _locationDbActions;

        public RepositoryWrapper(IDbContext context)
        {
            _context = context;
        }

        public IUserDbActions UserDbActions
        {
            get
            {
                _userDbActions ??= new UserDbActions(_context);
                return (_userDbActions);
            }
        }

        public ILocationDbActions locationDbActions
        {
            get
            {
                _locationDbActions ??= new LocationDbActions(_context);
                return (_locationDbActions);
            }
        }
    }
}
