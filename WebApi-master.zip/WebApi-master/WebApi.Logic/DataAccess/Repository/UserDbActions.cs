﻿using Dapper;
using System.Data;
using WebApi.Logic.DataAccess.Database.Interfaces;
using WebApi.Logic.DataAccess.Repository.Interfaces;
using WebApi.Logic.DataAccess.ResourceFile;
using WebApi.Models.DataObjects;
using WebApi.Models.RequestObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Logic.DataAccess.Repository
{
    public class UserDbActions : IUserDbActions
    {
        private readonly IDbContext _context;
        public UserDbActions(IDbContext context)
        {
            _context = context;
        }
        public async Task<ClientResponseDTO> CreateUser(AddClientRequestDTO UserInfo)
        {
            using var connection = _context.CreateConnection();

            return await connection.QueryFirstOrDefaultAsync<ClientResponseDTO>(SQLResources.AddClients,
                new { UserInfo.Username, UserInfo.EmailAddress, UserInfo.CellNo, UserInfo.Password, UserInfo.ProvinceID, UserInfo.CityID },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<GetProfileDetailsByClientDTO> GetProfileDetailsByClientID(Guid ClientID)
        {
            using var connection = _context.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<GetProfileDetailsByClientDTO>(SQLResources.GetProfileDetailsByClient,
                new { ClientID }, commandType: CommandType.StoredProcedure);
        }

        public async Task<ClientResponseDTO> LoginUser(LoginUserRequestDTO UserInfo)
        {
            using var connection = _context.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<ClientResponseDTO>(SQLResources.LoginUser,
                new { UserInfo.EmailAddress, UserInfo.Password },
                commandType: CommandType.StoredProcedure);
        }

        public async Task InsertClientFileLocations(List<ClientFileLocationDTO> ClientFileLocations)
        {
            using var connection = _context.CreateConnection();

            foreach (var FileLocation in ClientFileLocations)
            {
                await connection.ExecuteAsync(SQLResources.InsertFileLocation,
                new
                {
                    FileLocation.ClientID,
                    FileLocation.FileLocationPath,
                    FileLocation.FileName,
                    FileLocation.IsProfilePicture,
                    FileLocation.PictureSrc
                },
                commandType: CommandType.StoredProcedure);
            }
        }

        public async Task DeleteFileLocationPerClient(Guid ClientID)
        {
            using var connection = _context.CreateConnection();
            
            await connection.ExecuteAsync(SQLResources.DeleteFileLocationPerClient,
            new { ClientID },
            commandType: CommandType.StoredProcedure);
        }

        public async Task<List<ClientFileLocationDTO>> GetImageLocationPerUser(Guid ClientID)
        {
            using var connection = _context.CreateConnection();
            var result = await connection.QueryAsync<ClientFileLocationDTO>(SQLResources.GetImageLocationPerUser,
                new { ClientID }, commandType: CommandType.StoredProcedure);
            return result.ToList();
        }

        public async Task<List<ClientFileLocationDTO>> GetClientProfilePicturePath()
        {
            using var connection = _context.CreateConnection();
            var result = await connection.QueryAsync<ClientFileLocationDTO>(SQLResources.GetClientProfilePictures,
                new { }, commandType: CommandType.StoredProcedure);
            return result.ToList();
        }

    }
}
