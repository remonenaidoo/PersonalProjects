﻿using System.Security.Claims;

namespace WebApi.Logic.GenerateToken.interfaces
{
    public interface ITokenHelper
    {
        Task<string> GenerateJwtToken(Guid userName);
        Task<ClaimsPrincipal> GetValueFromToken(string token);
        Task<T> GetClaimValue<T>(string type, ClaimsIdentity identity);
    }
}
