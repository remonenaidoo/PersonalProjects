﻿using WebApi.Logic.Exceptions.Interfaces;
using WebApi.Models.Enums;

namespace WebApi.Logic.Exceptions
{
    public class ErrorResponses : IErrorResponses
    {
        public async Task<CustomExceptions> GetErrorReponse(ErrorTypes errorType)
        {
            var mappedResponse = ExceptionMessages.FirstOrDefault(x => x.Key == errorType).Value;

            if (mappedResponse != null)
                return mappedResponse;
            else
                throw new CustomExceptions("Unable to map error responses");
        }

        private static readonly Dictionary<ErrorTypes, CustomExceptions> ExceptionMessages = new Dictionary<ErrorTypes, CustomExceptions>
        {
            {
                ErrorTypes.InvalidUser, new CustomExceptions("User does not exist")
            }
       };
    }
}
