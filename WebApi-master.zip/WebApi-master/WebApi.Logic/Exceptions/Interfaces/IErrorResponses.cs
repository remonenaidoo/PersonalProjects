﻿using WebApi.Models.Enums;

namespace WebApi.Logic.Exceptions.Interfaces
{
    public interface IErrorResponses
    {
        Task<CustomExceptions> GetErrorReponse(ErrorTypes errorType);
    }
}
