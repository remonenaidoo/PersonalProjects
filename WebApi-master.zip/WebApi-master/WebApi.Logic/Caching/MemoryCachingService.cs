﻿using Microsoft.Extensions.Caching.Memory;
using WebApi.Logic.Caching.interfaces;

namespace WebApi.Logic.Caching
{
    public class MemoryCachingService : IMemoryCachingService
    {
        private readonly IMemoryCache _memoryCache;

        public MemoryCachingService(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        public async Task<T> GetOrSetAsync<T>(string key, Func<Task<T>> getItemCallback, TimeSpan cacheDuration)
        {
            if (_memoryCache.TryGetValue(key, out T cachedData))
            {
                return cachedData;
            }

            T data = await getItemCallback();

            var cacheOptions = new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = cacheDuration
            };
            _memoryCache.Set(key, data, cacheOptions);

            return data;
        }
    }
}
