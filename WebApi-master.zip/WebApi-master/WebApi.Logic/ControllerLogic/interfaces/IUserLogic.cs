﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi.Models.RequestObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Logic.ControllerLogic.interfaces
{
    public interface IUserLogic
    {
        Task<ClientResponseDTO> CreateUser(AddClientRequestDTO UserInfo);
        Task<LoginUserResponseDTO> LoginUser(LoginUserRequestDTO UserCreds);
        Task<GetProfileDetailsByClientDTO> GetProfileDetailsByClient(Guid ClientID);
        Task<string> GetValueFromToken(string token);
        Task<ClientResponseDTO> UploadImages(ImageUploadRequestDTO request);
    }
}
