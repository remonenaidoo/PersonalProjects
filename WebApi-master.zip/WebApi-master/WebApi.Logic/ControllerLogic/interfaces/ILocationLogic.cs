﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi.Models.DataObjects;
using WebApi.Models.RequestObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Logic.ControllerLogic.interfaces
{
    public interface ILocationLogic
    {
        Task<List<CitiesDTO>> GetCitiesbyProvince(int? ProvinceID);
        Task<List<ProvincesDTO>> GetProvinces();
        Task<LocationDataDTO> GetLocationDataPerAUser();
        Task<List<GetClientsByLocationResponseDTO>> GetClientsByLocation(GetClientsByLocationRequestDTO SelectedLocation);
        Task<List<GetRegisteredClientsDTO>> GetRegisteredClients();
    }
}
