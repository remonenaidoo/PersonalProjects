﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi.Models.DataObjects;

namespace WebApi.Logic.ControllerLogic.interfaces
{
    public interface IImagesLogic
    {
        Task<List<ClientFileLocationDTO>> GetProfilePicture();
        Task<List<string>> GetAllPicturesPerClient(Guid clientId);
    }
}
