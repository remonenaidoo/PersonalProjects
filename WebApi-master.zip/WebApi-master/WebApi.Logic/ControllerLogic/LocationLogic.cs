﻿using Newtonsoft.Json;
using WebApi.Logic.Caching.interfaces;
using WebApi.Logic.ControllerLogic.interfaces;
using WebApi.Logic.DataAccess.Repository.Interfaces;
using WebApi.Models.DataObjects;
using WebApi.Models.RequestObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Logic.ControllerLogic
{
    public class LocationLogic : ILocationLogic
    {
        private readonly IRepositoryWrapper _repositoryWrapper;
        private readonly IMemoryCachingService _cachingService;
        public LocationLogic(IMemoryCachingService cachingService, IRepositoryWrapper repositoryWrapper)
        {
            _repositoryWrapper = repositoryWrapper;
            _cachingService = cachingService;
        }
        public async Task<List<CitiesDTO>> GetCitiesbyProvince(int? ProvinceID)
        {
            var Cities = await _repositoryWrapper.locationDbActions.GetCitiesbyProvince(ProvinceID);
            return Cities;
        }
        public async Task<List<ProvincesDTO>> GetProvinces()
        {
            var result = await _cachingService.GetOrSetAsync("GetProvincesCacheKey", async () =>
            {
                var Provinces = await _repositoryWrapper.locationDbActions.GetProvinces();
                return Provinces;
            },
            TimeSpan.FromMinutes(60)); // Cache for 60 minutes

            return result;
        }
        public async Task<LocationDataDTO> GetLocationDataPerAUser()
        {
            var result = await _cachingService.GetOrSetAsync("GetLocationDataCacheKey", async () =>
            {
                var locationData = await _repositoryWrapper.locationDbActions.GetLocationDataPerAUser();
                var result = JsonConvert.DeserializeObject<LocationDataDTO>(locationData);
                return result;
            },
            TimeSpan.FromMinutes(60)); 

            return result;
        }
        public async Task<List<GetClientsByLocationResponseDTO>> GetClientsByLocation(GetClientsByLocationRequestDTO SelectedLocation)
        {
            var clients = await _repositoryWrapper.locationDbActions.GetClientsBySelectedLocation(SelectedLocation);
            return clients;
        }
        public async Task<List<GetRegisteredClientsDTO>> GetRegisteredClients()
        {
            var clients = await _repositoryWrapper.locationDbActions.GetRegisteredClients();
            return clients;
        }
    }
}
