﻿using System.Security.Claims;
using WebApi.Logic.ControllerLogic.interfaces;
using WebApi.Logic.DataAccess.Repository.Interfaces;
using WebApi.Logic.GenerateToken.interfaces;
using WebApi.Models.DataObjects;
using WebApi.Models.RequestObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Logic.ControllerLogic
{
    public class UserLogic : IUserLogic
    {
        private readonly IRepositoryWrapper _repositoryWrapper;
        private readonly ITokenHelper _tokenHelper;
        private readonly IImagesLogic _imagesLogic;
        private readonly string _imageBasePath;

        public UserLogic(IRepositoryWrapper repositoryWrapper, ITokenHelper tokenHelper, IImagesLogic imagesLogic)
        {
            _repositoryWrapper = repositoryWrapper;
            _tokenHelper = tokenHelper;
            _imagesLogic = imagesLogic;
            _imageBasePath = "C:\\Users\\HP X360\\source\\repos\\user-application\\src\\assets\\images\\Clients";
    }
        public async Task<ClientResponseDTO> CreateUser(AddClientRequestDTO UserInfo)
        {
            var mappedData = new AddClientRequestDTO()
            {
                EmailAddress = UserInfo.EmailAddress,
                Password = UserInfo.Password,
                Username = UserInfo.Username,
                CellNo = UserInfo.CellNo,
                ProvinceID = UserInfo.ProvinceID,
                CityID = UserInfo.CityID,
            };

            var ClientResponse = await _repositoryWrapper.UserDbActions.CreateUser(mappedData);
            ClientResponse.Success = true;

            return ClientResponse;
        }
        public async Task<GetProfileDetailsByClientDTO> GetProfileDetailsByClient(Guid ClientID)
            {
            var ProfileDetails = await _repositoryWrapper.UserDbActions.GetProfileDetailsByClientID(ClientID);
            ProfileDetails.OtherPicturesUrls = await _imagesLogic.GetAllPicturesPerClient(ClientID);
            return ProfileDetails;
        }
        public async Task<string> GetValueFromToken(string token)
        {
            var claimsPrinciple = await _tokenHelper.GetValueFromToken(token);

            if (claimsPrinciple == null)
                return "";

            var simplePrinciple = claimsPrinciple.Identity as ClaimsIdentity;
            var jwtClientId = simplePrinciple?.Name;
            return jwtClientId;
        }
        public async Task<LoginUserResponseDTO> LoginUser(LoginUserRequestDTO UserCreds)
        {
            var AuthenticateUserResponse = new LoginUserResponseDTO();

            var mappedData = new LoginUserRequestDTO()
            {
                EmailAddress = UserCreds.EmailAddress,
                Password = UserCreds.Password
            };

            var UserExists = await _repositoryWrapper.UserDbActions.LoginUser(mappedData);

            if (UserExists.Success)
            {
                var token = await _tokenHelper.GenerateJwtToken(UserExists.ClientID);

                AuthenticateUserResponse.Token = token;
                AuthenticateUserResponse.ResponseMessage = "Success";
                AuthenticateUserResponse.Success = true;

                return AuthenticateUserResponse;
            }

            AuthenticateUserResponse.ResponseMessage = "Please pass the valid Username and Password";
            return AuthenticateUserResponse;
        }
        public async Task<ClientResponseDTO> UploadImages(ImageUploadRequestDTO ImageUploadRequest)
        {
            if (!Guid.TryParse(ImageUploadRequest.ClientId, out Guid clientId))
            {
                return new ClientResponseDTO { Success = false, ResponseMessage = "" };
            }

            var clientFolder = Path.Combine(_imageBasePath, clientId.ToString());

            //if (!Directory.Exists(clientFolder))
            //{
             //   Directory.CreateDirectory(clientFolder);
            //}

            var ClientFileLocations = new List<ClientFileLocationDTO>();

            for (int i = 0; i < ImageUploadRequest.Images.Count; i++)
            {
                var base64Image = ImageUploadRequest.Images[i];
                //var imageBytes = Convert.FromBase64String(await GetBase64ImageContent(base64Image.Src));

                var imageFormat = await GetImageFormat(base64Image.Src);
                var fileName = $"{i}.{imageFormat.ToLower()}";

                //var filePath = Path.Combine(clientFolder, fileName);

                //using var stream = new FileStream(filePath, FileMode.Create);
                //await stream.WriteAsync(imageBytes);

                ClientFileLocations.Add(new ClientFileLocationDTO
                {
                    ClientID = clientId,
                    FileLocationPath = clientFolder,
                    FileName = fileName,
                    IsProfilePicture = ImageUploadRequest.Images[i].IsProfile,
                    PictureSrc = ImageUploadRequest.Images[i].Src

                });
            }

            await _repositoryWrapper.UserDbActions.DeleteFileLocationPerClient(clientId);
            await _repositoryWrapper.UserDbActions.InsertClientFileLocations(ClientFileLocations);

            return new ClientResponseDTO { ClientID = clientId, ResponseMessage = "" , Success = true};
        }
        private static async Task<string> GetBase64ImageContent(string base64String)
        {
            var startIndex = base64String.IndexOf(",") + 1;
            return base64String.Substring(startIndex);
        }
        private static async Task<string> GetImageFormat(string base64String)
        {
            var header = base64String.Substring(0, base64String.IndexOf(','));
            var formatStartIndex = header.IndexOf('/') + 1;
            var formatEndIndex = header.IndexOf(';');
            return header.Substring(formatStartIndex, formatEndIndex - formatStartIndex);
        }

    }
}
