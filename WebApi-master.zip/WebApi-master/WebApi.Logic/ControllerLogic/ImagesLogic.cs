﻿using WebApi.Logic.ControllerLogic.interfaces;
using WebApi.Logic.DataAccess.Repository.Interfaces;
using WebApi.Models.DataObjects;

namespace WebApi.Logic.ControllerLogic
{
    public class ImagesLogic: IImagesLogic
    {
        private readonly string _imageBasePath;
        private readonly IRepositoryWrapper _repositoryWrapper;
        public ImagesLogic(IRepositoryWrapper repositoryWrapper)
        {
            _repositoryWrapper = repositoryWrapper;
            _imageBasePath = "C:\\Users\\HP X360\\source\\repos\\user-application\\src\\assets\\images";
        }

        public async Task<List<ClientFileLocationDTO>> GetProfilePicture()
        {
            var ClientProfilePictures = await _repositoryWrapper.UserDbActions.GetClientProfilePicturePath();

            ClientProfilePictures.ForEach(profilepicture =>
            profilepicture.FileLocationPath = profilepicture.FileLocationPath
            .Replace(_imageBasePath, "") + '\\' + profilepicture.FileName);

            return ClientProfilePictures;
        }

        public async Task<List<string>> GetAllPicturesPerClient(Guid clientId)
        {
            var ImageUrl = await _repositoryWrapper.UserDbActions.GetImageLocationPerUser(clientId);
           // List<string> FileLocationPath = ImageUrl.Select(x => x.FileLocationPath.Replace(_imageBasePath, "") + '\\' + x.FileName).ToList();
            List<string> FileLocationPath = ImageUrl.Select(x => x.PictureSrc).ToList();
            return FileLocationPath;
        }
    }
}
