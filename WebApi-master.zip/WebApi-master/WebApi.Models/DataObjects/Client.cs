﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Models.DataObjects
{
    public class Client
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string? ProfilePicturePath { get; set; }
        public List<string?> OtherPicturePaths { get; set; } = new List<string?>();
    }
}
