﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Models.DataObjects
{
    public class ProvincesDTO
    {
        public int ProvinceID { get; set; }
        public string ProvinceName { get; set; }

    }
}
