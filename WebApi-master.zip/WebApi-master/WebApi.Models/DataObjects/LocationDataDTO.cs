﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Models.DataObjects
{
    public class Suburb
    {
        public int SuburbID { get; set; }
        public string SuburbName { get; set; }
        public int SuburbCount { get; set; }
    }

    public class City
    {
        public int CityID { get; set; }
        public string CityName { get; set; }
        public int CityCount { get; set; }
        public List<Suburb> Suburbs { get; set; }
    }

    public class Province
    {
        public int ProvinceID { get; set; }
        public string ProvinceName { get; set; }
        public int ProvinceCount { get; set; }
        public List<City> Cities { get; set; }
    }

    public class LocationDataDTO
    {
        public List<Province> LocationData { get; set; }
    }


}
