﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Models.DataObjects
{
    public class ClientFileLocationDTO
    {
        public Guid ClientID { get; set; }
        public string FileLocationPath { get; set; }
        public string FileName { get; set; }
        public bool IsProfilePicture { get; set; }
        public string PictureSrc { get; set;}
    }
}
