﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Models.ResponseObjects
{
    public class GetProfileDetailsByClientDTO
    {
        public Guid ClientID { get; set; }
        public string Username { get; set; }
        public string Name { get; set; }
        public string CellNo { get; set; }
        public bool IsVerified { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string Description { get; set; }
        public string Likes { get; set; }
        public string ProvinceName { get; set; }
        public int ProvinceID { get; set; }
        public string CityName { get; set; }
        public int CityID { get; set; }
        public string SuburbName { get; set; }
        public List<string> OtherPicturesUrls { get; set; }

    }
}

