﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Models.ResponseObjects
{
    public class GetClientsByLocationResponseDTO
    {
        public Guid ClientID { get; set; }
        public string Username { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public string? ImageBase64 { get; set; }
    }
}
