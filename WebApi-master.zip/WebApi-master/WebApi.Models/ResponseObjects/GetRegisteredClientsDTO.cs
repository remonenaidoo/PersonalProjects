﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Models.ResponseObjects
{
        public class GetRegisteredClientsDTO
        {
            public Guid ClientID { get; set; }
            public string Username { get; set; }
            public string Name { get; set; }
            public string Location { get; set; }
            public string? ImageBase64 { get; set; }
            public int ProvinceID { get; set; }
            public int CityID { get; set; }
            public int SuburbID { get; set; }

        }
}
