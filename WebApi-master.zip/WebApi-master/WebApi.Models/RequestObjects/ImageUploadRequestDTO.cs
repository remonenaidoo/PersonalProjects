﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi.Models.DataObjects;

namespace WebApi.Models.RequestObjects
{
    public class ImageUploadRequestDTO
    {
        public string ClientId { get; set; }
        public List<ImageUploadInfDTO> Images { get; set; }
    }
}
