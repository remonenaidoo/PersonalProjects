﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Models.RequestObjects
{
    public class GetClientsByLocationRequestDTO
    {
        public string LocationType { get; set; }
        public int ID { get; set; }

    }
}
