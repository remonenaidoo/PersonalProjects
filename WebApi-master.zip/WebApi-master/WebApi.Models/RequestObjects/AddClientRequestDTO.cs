﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Models.RequestObjects
{
    public class AddClientRequestDTO
    {
        public string? Username { get; set; }
        public string? EmailAddress { get; set; }
        public string? CellNo { get; set; }
        public string? Password { get; set; }
        public int? ProvinceID { get; set; }
        public int? CityID { get; set; }
    }
}
