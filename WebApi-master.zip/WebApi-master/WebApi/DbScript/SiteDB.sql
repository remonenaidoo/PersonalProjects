USE [master]
GO
/****** Object:  Database [SiteDB]    Script Date: 10/23/2023 9:17:10 PM ******/
CREATE DATABASE [SiteDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'SiteDB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\SiteDB.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'SiteDB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\SiteDB_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [SiteDB] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [SiteDB].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [SiteDB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [SiteDB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [SiteDB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [SiteDB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [SiteDB] SET ARITHABORT OFF 
GO
ALTER DATABASE [SiteDB] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [SiteDB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [SiteDB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [SiteDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [SiteDB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [SiteDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [SiteDB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [SiteDB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [SiteDB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [SiteDB] SET  DISABLE_BROKER 
GO
ALTER DATABASE [SiteDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [SiteDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [SiteDB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [SiteDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [SiteDB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [SiteDB] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [SiteDB] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [SiteDB] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [SiteDB] SET  MULTI_USER 
GO
ALTER DATABASE [SiteDB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [SiteDB] SET DB_CHAINING OFF 
GO
ALTER DATABASE [SiteDB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [SiteDB] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [SiteDB] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [SiteDB] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [SiteDB] SET QUERY_STORE = OFF
GO
USE [SiteDB]
GO
/****** Object:  Schema [Client]    Script Date: 10/23/2023 9:17:10 PM ******/
CREATE SCHEMA [Client]
GO
/****** Object:  Schema [SouthAfrica]    Script Date: 10/23/2023 9:17:10 PM ******/
CREATE SCHEMA [SouthAfrica]
GO
/****** Object:  UserDefinedTableType [dbo].[ClientFileLocationTableType]    Script Date: 10/23/2023 9:17:10 PM ******/
CREATE TYPE [dbo].[ClientFileLocationTableType] AS TABLE(
	[ClientID] [uniqueidentifier] NULL,
	[FileLocationPath] [nvarchar](max) NULL,
	[FileName] [varchar](250) NULL
)
GO
/****** Object:  Table [Client].[AdditionalDetails]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Client].[AdditionalDetails](
	[ClientsAdditionalDetailsID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [uniqueidentifier] NULL,
	[Description] [varchar](250) NULL,
	[Likes] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[ClientsAdditionalDetailsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [Client].[Balance]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Client].[Balance](
	[ClientBalanceID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [uniqueidentifier] NOT NULL,
	[Balance] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[ClientBalanceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [Client].[Clients]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Client].[Clients](
	[ClientID] [uniqueidentifier] NOT NULL,
	[Username] [varchar](50) NULL,
	[EmailAddress] [varchar](100) NULL,
	[CellNo] [varchar](20) NULL,
	[DateCreated] [datetime] NULL,
	[IsActive] [bit] NULL,
	[IsVerified] [bit] NULL,
	[Name] [varchar](100) NULL,
	[Surname] [varchar](100) NULL,
	[DateOfBirth] [datetime] NULL,
	[GenderID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ClientID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[EmailAddress] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[CellNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [Client].[Credentials]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Client].[Credentials](
	[ClientCredentials] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [uniqueidentifier] NOT NULL,
	[PasswordHash] [binary](64) NOT NULL,
	[Salt] [uniqueidentifier] NULL,
PRIMARY KEY CLUSTERED 
(
	[ClientCredentials] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [Client].[FileLocation]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Client].[FileLocation](
	[FileLocationID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [uniqueidentifier] NULL,
	[FileLocationPath] [nvarchar](max) NULL,
	[FileName] [varchar](250) NULL,
	[IsProfilePicture] [bit] NULL,
	[PictureSource] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[FileLocationID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [Client].[Gender]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Client].[Gender](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[GenderID] [int] NULL,
	[Gender] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [Client].[RegisteredAddress]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Client].[RegisteredAddress](
	[RegisteredAddressID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [uniqueidentifier] NULL,
	[AddressDescription] [varchar](max) NULL,
	[CountryID] [int] NULL,
	[ProvinceID] [int] NULL,
	[CityID] [int] NULL,
	[SuburbID] [int] NULL,
	[PostalCode] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[RegisteredAddressID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [SouthAfrica].[Cities]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [SouthAfrica].[Cities](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CityID] [int] NOT NULL,
	[CityName] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [SouthAfrica].[MajorCitiesPerProvince]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [SouthAfrica].[MajorCitiesPerProvince](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CitiesPerProvinceID] [int] NULL,
	[ProvinceID] [int] NULL,
	[CityID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [SouthAfrica].[Provinces]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [SouthAfrica].[Provinces](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProvinceID] [int] NOT NULL,
	[ProvinceName] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [SouthAfrica].[Suburbs]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [SouthAfrica].[Suburbs](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SuburbID] [int] NOT NULL,
	[SuburbName] [varchar](100) NULL,
	[MajorCityID] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [SouthAfrica].[SuburbsCapeTown]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [SouthAfrica].[SuburbsCapeTown](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SuburbID] [int] NOT NULL,
	[SuburbName] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [SouthAfrica].[SuburbsDurban]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [SouthAfrica].[SuburbsDurban](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SuburbID] [int] NOT NULL,
	[SuburbName] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [SouthAfrica].[SuburbsJohannesburg]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [SouthAfrica].[SuburbsJohannesburg](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SuburbID] [int] NOT NULL,
	[SuburbName] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Index [IX_Cities_CityID]    Script Date: 10/23/2023 9:17:10 PM ******/
CREATE NONCLUSTERED INDEX [IX_Cities_CityID] ON [SouthAfrica].[Cities]
(
	[CityID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Provinces_ProvinceID]    Script Date: 10/23/2023 9:17:10 PM ******/
CREATE NONCLUSTERED INDEX [IX_Provinces_ProvinceID] ON [SouthAfrica].[Provinces]
(
	[ProvinceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Suburbs_SuburbID]    Script Date: 10/23/2023 9:17:10 PM ******/
CREATE NONCLUSTERED INDEX [IX_Suburbs_SuburbID] ON [SouthAfrica].[Suburbs]
(
	[SuburbID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [Client].[Clients] ADD  DEFAULT (newid()) FOR [ClientID]
GO
ALTER TABLE [Client].[AdditionalDetails]  WITH CHECK ADD FOREIGN KEY([ClientID])
REFERENCES [Client].[Clients] ([ClientID])
GO
ALTER TABLE [Client].[Balance]  WITH CHECK ADD FOREIGN KEY([ClientID])
REFERENCES [Client].[Clients] ([ClientID])
GO
ALTER TABLE [Client].[Credentials]  WITH CHECK ADD  CONSTRAINT [FK_ClientCredentials] FOREIGN KEY([ClientID])
REFERENCES [Client].[Clients] ([ClientID])
GO
ALTER TABLE [Client].[Credentials] CHECK CONSTRAINT [FK_ClientCredentials]
GO
/****** Object:  StoredProcedure [Client].[AddClients]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Client].[AddClients]
    @Username VARCHAR(50), 
	@EmailAddress VARCHAR(100), 
	@CellNo VARCHAR(20),
    @Password NVARCHAR(50),
	@ProvinceID int,
	@CityID int
AS
BEGIN
declare @responseMessage bit = 0 

    SET NOCOUNT ON

    IF NOT EXISTS (SELECT 1 FROM [Client].[Clients] WHERE EmailAddress = @EmailAddress)
    BEGIN
		DECLARE @salt UNIQUEIDENTIFIER=NEWID()
		CREATE TABLE #TempTable (LastGeneratedID UNIQUEIDENTIFIER);
		declare @ClientID UNIQUEIDENTIFIER

	BEGIN TRY
	    INSERT INTO [Client].[Clients] (Username,EmailAddress,CellNo,DateCreated,IsActive)
		OUTPUT INSERTED.ClientID INTO #TempTable (LastGeneratedID)
        VALUES(@Username,@EmailAddress,@CellNo,GETDATE(),1)

		set @ClientID = (SELECT LastGeneratedID FROM #TempTable)
	    DROP TABLE #TempTable;

		INSERT INTO [Client].[RegisteredAddress]([ClientID],[ProvinceID],[CityID])
		VALUES(@ClientID,@ProvinceID,@CityID)

        INSERT INTO [Client].[Credentials] (ClientID,PasswordHash,Salt)
        VALUES(@ClientID, HASHBYTES('SHA2_512', @Password+CAST(@salt AS NVARCHAR(36))), @salt)
       SET @responseMessage = 1

    END TRY

    BEGIN CATCH
        SET @responseMessage = 0
    END CATCH

	select @responseMessage as responseMessage , @ClientID as ClientID
	end
END
GO
/****** Object:  StoredProcedure [Client].[DeleteFileLocationPerClient]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [Client].[DeleteFileLocationPerClient]
    @ClientID uniqueidentifier
AS
BEGIN
Delete from [Client].[FileLocation] Where [ClientID] = @ClientID
END;
GO
/****** Object:  StoredProcedure [Client].[GetClientDetailsBySelectedLocation]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Client].[GetClientDetailsBySelectedLocation]
    @LocationType NVARCHAR(50) = null,
    @ID INT = null
AS
BEGIN
    SET NOCOUNT ON;

    IF (@LocationType IS NULL OR @ID IS NULL)
    BEGIN
        SELECT
            C.ClientID,
            C.Username,
            CONCAT(C.[Name], ' ', C.[Surname]) AS Name,
            P.[ProvinceName] AS Location
        FROM [Client].[RegisteredAddress] R
        JOIN [Client].[Clients] C ON C.ClientID = R.ClientID
        JOIN [SouthAfrica].[Provinces] P ON R.[ProvinceID] = P.[ProvinceID];
    END
    ELSE
    BEGIN
        SELECT
            C.ClientID,
            C.Username,
            CONCAT(C.[Name], ' ', C.[Surname]) AS Name,
            CASE
                WHEN @LocationType = 'ProvinceID' THEN P.[ProvinceName]
                WHEN @LocationType = 'CityID' THEN CI.[CityName]
                WHEN @LocationType = 'SuburbID' THEN S.[SuburbName]
            END AS Location
        FROM [Client].[RegisteredAddress] R
        JOIN [Client].[Clients] C ON C.ClientID = R.ClientID
        LEFT JOIN [SouthAfrica].[Provinces] P ON @LocationType = 'ProvinceID' AND P.[ProvinceID] = @ID
        LEFT JOIN [SouthAfrica].[Cities] CI ON @LocationType = 'CityID' AND CI.[CityID] = @ID
        LEFT JOIN [SouthAfrica].[Suburbs] S ON @LocationType = 'SuburbID' AND S.[SuburbID] = @ID
        WHERE
            (@LocationType = 'ProvinceID' AND R.[ProvinceID] = @ID)
            OR (@LocationType = 'CityID' AND R.[CityID] = @ID)
            OR (@LocationType = 'SuburbID' AND R.[SuburbID] = @ID);
    END
END;
GO
/****** Object:  StoredProcedure [Client].[GetClientProfilePictures]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [Client].[GetClientProfilePictures]
As
Begin
SELECT 
       [ClientID]
      ,[FileLocationPath]
      ,[FileName]
	  ,[IsProfilePicture]
	  ,[PictureSource] as PictureSrc
  FROM [Client].[FileLocation]
  Where [IsProfilePicture] ='true'
END
GO
/****** Object:  StoredProcedure [Client].[GetImageLocationPerUser]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [Client].[GetImageLocationPerUser]
(
@ClientID uniqueidentifier 
)
As
Begin
SELECT 
       [ClientID]
      ,[FileLocationPath]
      ,[FileName]
	  ,[IsProfilePicture]
	  ,[PictureSource] as PictureSrc
  FROM [Client].[FileLocation]
  Where ClientID = @ClientID
END
GO
/****** Object:  StoredProcedure [Client].[GetProfileDetailsByClient]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Client].[GetProfileDetailsByClient]
@ClientID uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        C.ClientID,
        C.Username,
        CONCAT(C.[Name], ' ', C.[Surname]) AS Name,
        C.[CellNo],
        C.[IsVerified],
        C.[DateOfBirth],
        G.[Gender],
        AD.[Description],
        AD.[Likes],
        P.[ProvinceName],
		p.ProvinceID,
        CT.[CityName],
		ct.CityID,
        S.[SuburbName]
    FROM [Client].[Clients] C
    LEFT JOIN [Client].[AdditionalDetails] AD 
	ON C.ClientID = AD.ClientID
    LEFT JOIN [Client].[RegisteredAddress] RA 
	ON C.ClientID = RA.ClientID
    LEFT JOIN [SouthAfrica].[Provinces] P 
	ON RA.ProvinceID = P.[ProvinceID]
    LEFT JOIN [SouthAfrica].[Cities] CT 
	ON RA.CityID = CT.[CityID]
    LEFT JOIN [SouthAfrica].[Suburbs] S 
	ON RA.SuburbID = S.[SuburbID]
    LEFT JOIN [Client].[Gender] G 
	ON G.[GenderID] = C.[GenderID]
    WHERE C.ClientID = @ClientID
END;
GO
/****** Object:  StoredProcedure [Client].[GetRegisteredClients]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Client].[GetRegisteredClients]
AS
BEGIN
    SET NOCOUNT ON;
        SELECT
            C.ClientID,
            C.Username,
            CONCAT(C.[Name], ' ', C.[Surname]) AS Name,
            P.[ProvinceName] AS Location,
			R.ProvinceID AS 'ProvinceID',
			R.CityID AS 'CityID',
			R.SuburbID AS 'SuburbID'
        FROM [Client].[RegisteredAddress] R
        JOIN [Client].[Clients] C ON C.ClientID = R.ClientID
        JOIN [SouthAfrica].[Provinces] P ON R.[ProvinceID] = P.[ProvinceID];
END;
GO
/****** Object:  StoredProcedure [Client].[InsertFileLocation]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Client].[InsertFileLocation]
    @ClientID uniqueidentifier,
    @FileLocationPath nvarchar(max),
    @FileName varchar(250),
	@IsProfilePicture bit,
	@PictureSrc nvarchar(max) 
AS
BEGIN
    INSERT INTO [Client].[FileLocation] (ClientID, FileLocationPath, FileName,IsProfilePicture,PictureSource)
    VALUES (@ClientID, @FileLocationPath, @FileName,@IsProfilePicture,@PictureSrc);
END;
GO
/****** Object:  StoredProcedure [Client].[LocationDataPerUsers]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [Client].[LocationDataPerUsers]
as 
begin
Create table #tempTable(LocationData nvarchar(max))
insert into #tempTable
select (
    SELECT 
        p.ProvinceID,
        p.ProvinceName,
        COUNT(ra.ProvinceID) AS ProvinceCount,
        (
            SELECT 
                c.CityID,
                c.CityName,
                COUNT(ra.CityID) AS CityCount,
                (
                    SELECT 
                        s.SuburbID,
                        s.SuburbName,
                        COUNT(ra.SuburbID) AS SuburbCount
                    FROM [SouthAfrica].Provinces p2
                    LEFT JOIN [SouthAfrica].MajorCitiesPerProvince mcpp ON p2.ProvinceID = mcpp.ProvinceID
                    LEFT JOIN [SouthAfrica].Cities c2 ON mcpp.CityID = c2.CityID
                    LEFT JOIN [SouthAfrica].Suburbs s ON c2.CityID = s.MajorCityID
                    LEFT JOIN [Client].[RegisteredAddress] ra ON s.SuburbID = ra.SuburbID
                    WHERE c2.CityID = c.CityID
                    GROUP BY s.SuburbID, s.SuburbName
                    FOR JSON PATH
                ) AS Suburbs
            FROM [SouthAfrica].Provinces p1
            LEFT JOIN [SouthAfrica].MajorCitiesPerProvince mcpp ON p1.ProvinceID = mcpp.ProvinceID
            LEFT JOIN [SouthAfrica].Cities c ON mcpp.CityID = c.CityID
            LEFT JOIN [Client].[RegisteredAddress] ra ON c.CityID = ra.CityID
            WHERE p1.ProvinceID = p.ProvinceID
            GROUP BY c.CityID, c.CityName
            FOR JSON PATH
        ) AS Cities
    FROM [SouthAfrica].Provinces p
    LEFT JOIN [SiteDB].[Client].[RegisteredAddress] ra ON p.ProvinceID = ra.ProvinceID
    GROUP BY p.ProvinceID, p.ProvinceName
    FOR JSON PATH, ROOT('LocationData')
	) as LocationData
	select top 1 LocationData from #tempTable
	Drop table #tempTable
end
GO
/****** Object:  StoredProcedure [Client].[LocationDataPerUsersCopy]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [Client].[LocationDataPerUsersCopy]
as 
begin
    SELECT 
        p.ProvinceID,
        p.ProvinceName,
        COUNT(ra.ProvinceID) AS ProvinceCount,
        (
            SELECT 
                c.CityID,
                c.CityName,
                COUNT(ra.CityID) AS CityCount,
                (
                    SELECT 
                        s.SuburbID,
                        s.SuburbName,
                        COUNT(ra.SuburbID) AS SuburbCount
                    FROM [SouthAfrica].Provinces p2
                    LEFT JOIN [SouthAfrica].MajorCitiesPerProvince mcpp ON p2.ProvinceID = mcpp.ProvinceID
                    LEFT JOIN [SouthAfrica].Cities c2 ON mcpp.CityID = c2.CityID
                    LEFT JOIN [SouthAfrica].Suburbs s ON c2.CityID = s.MajorCityID
                    LEFT JOIN [Client].[RegisteredAddress] ra ON s.SuburbID = ra.SuburbID
                    WHERE c2.CityID = c.CityID
                    GROUP BY s.SuburbID, s.SuburbName
                    FOR JSON PATH
                ) AS Suburbs
            FROM [SouthAfrica].Provinces p1
            LEFT JOIN [SouthAfrica].MajorCitiesPerProvince mcpp ON p1.ProvinceID = mcpp.ProvinceID
            LEFT JOIN [SouthAfrica].Cities c ON mcpp.CityID = c.CityID
            LEFT JOIN [Client].[RegisteredAddress] ra ON c.CityID = ra.CityID
            WHERE p1.ProvinceID = p.ProvinceID
            GROUP BY c.CityID, c.CityName
            FOR JSON PATH
        ) AS Cities
    FROM [SouthAfrica].Provinces p
    LEFT JOIN [SiteDB].[Client].[RegisteredAddress] ra ON p.ProvinceID = ra.ProvinceID
    GROUP BY p.ProvinceID, p.ProvinceName
    FOR JSON PATH, ROOT('LocationData'); -- Wrap the entire result in a root object
end
GO
/****** Object:  StoredProcedure [Client].[LoginUser]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Client].[LoginUser]
    @EmailAddress NVARCHAR(100), 
    @Password NVARCHAR(50)
AS
BEGIN
    DECLARE @SuccessMessage BIT = 0;
    DECLARE @userID UNIQUEIDENTIFIER;

    SET NOCOUNT ON;

    SELECT @userID = c.[ClientID]
    FROM [Client].[Clients] c
    INNER JOIN [Client].[Credentials] cr ON c.ClientID = cr.ClientID
    WHERE c.EmailAddress = @EmailAddress 
	AND cr.PasswordHash = HASHBYTES('SHA2_512', @Password + CAST(cr.Salt AS NVARCHAR(36)))
	AND c.IsActive = 1

    IF @userID IS NOT NULL
    BEGIN
        SET @SuccessMessage = 1;
    END

    SELECT '' AS responseMessage, @userID AS ClientID, @SuccessMessage as Success;
END;
GO
/****** Object:  StoredProcedure [SouthAfrica].[GetCitiesForProvince]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


Create procedure [SouthAfrica].[GetCitiesForProvince]
(
@ProvinceID int = null
)
as 
begin
select C.CityID, C.CityName
from [SouthAfrica].[MajorCitiesPerProvince] CP
Join [SouthAfrica].[Cities] C
on CP.[CityID] = C.[CityID]
WHERE CP.[ProvinceID] = @ProvinceID OR @ProvinceID IS NULL
Order by C.CityName Asc
end
GO
/****** Object:  StoredProcedure [SouthAfrica].[GetProvinces]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create Procedure [SouthAfrica].[GetProvinces]
as
Begin
SELECT [ProvinceID]
      ,[ProvinceName]
  FROM [SouthAfrica].[Provinces]
END
GO
/****** Object:  StoredProcedure [SouthAfrica].[LocationDataWithoutCount]    Script Date: 10/23/2023 9:17:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [SouthAfrica].[LocationDataWithoutCount]
as
begin
    SELECT 
        p.ProvinceID,
        p.ProvinceName,
        c.CityID,
        c.CityName,
        s.SuburbID,
        s.SuburbName
    INTO #TempLocation
    FROM [SouthAfrica].Provinces p
    LEFT JOIN [SouthAfrica].MajorCitiesPerProvince mcpp ON p.ProvinceID = mcpp.ProvinceID
    LEFT JOIN [SouthAfrica].Cities c ON mcpp.CityID = c.CityID
    LEFT JOIN [SouthAfrica].Suburbs s ON c.CityID = s.[MajorCityID];

    SELECT DISTINCT
        p.ProvinceID,
        p.ProvinceName,
        (
            SELECT DISTINCT
                c.CityID,
                c.CityName,
                (
                    SELECT 
                        s.SuburbID,
                        s.SuburbName
                    FROM #TempLocation s
                    WHERE c.CityID = s.CityID
                    FOR JSON PATH
                ) AS Suburbs
            FROM #TempLocation c
            WHERE p.ProvinceID = c.ProvinceID
            FOR JSON PATH
        ) AS Cities
    FROM #TempLocation p
    FOR JSON PATH;

	drop table #TempLocation
end
GO
USE [master]
GO
ALTER DATABASE [SiteDB] SET  READ_WRITE 
GO
