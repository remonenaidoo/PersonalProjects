﻿using Microsoft.AspNetCore.Mvc;
using WebApi.Logic.Caching.interfaces;
using WebApi.Logic.ControllerLogic.interfaces;
using WebApi.Logic.Logging.Interfaces;
using WebApi.Models.DataObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationServicesController : ControllerBase
    {
        private readonly ILocationLogic _locationLogic;
        private readonly IImagesLogic _imagesLogic;
        private readonly IMemoryCachingService _cachingService;
        private readonly ILoggerHelper _loggerHelper;

        public LocationServicesController(ILocationLogic locationLogic, IImagesLogic imagesLogic, IMemoryCachingService cachingService, ILoggerHelper loggerHelper)
        {
            _locationLogic = locationLogic;
            _imagesLogic = imagesLogic;
            _cachingService = cachingService;
            _loggerHelper = loggerHelper;
        }

        [HttpGet]
        [Route("GetCitiesbyProvince")]
        public async Task<List<CitiesDTO>> GetCitiesbyProvince(int? ProvinceID)
        {
            try
            {
                return await _locationLogic.GetCitiesbyProvince(ProvinceID);
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new List<CitiesDTO>();
            }
        }

        [HttpGet]
        [Route("GetProvinces")]
        public async Task<List<ProvincesDTO>> GetProvinces()
        {
            try
            {
                return await _locationLogic.GetProvinces();
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new List<ProvincesDTO>();
            }

        }

        [HttpGet]
        [Route("GetLocationData")]
        public async Task<LocationDataDTO> GetLocationData()
        {
            try
            {
                return await _locationLogic.GetLocationDataPerAUser();
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new LocationDataDTO();
            }
        }


        [HttpGet]
        [Route("GetRegisteredClients")]
        public async Task<List<GetRegisteredClientsDTO>> GetRegisteredClients()
        {
            try
            {
                var result = await _cachingService.GetOrSetAsync("GetRegisteredClientsCacheKey", async () =>
            {
                var Clients = await _locationLogic.GetRegisteredClients();
                var clientFileLocations = await _imagesLogic.GetProfilePicture();

                Dictionary<Guid, string> clientFileLocationMap = clientFileLocations.ToDictionary(c => c.ClientID, c => c.PictureSrc);

                foreach (var client in Clients)
                {
                    if (clientFileLocationMap.ContainsKey(client.ClientID))
                    {
                        client.ImageBase64 = clientFileLocationMap[client.ClientID];
                    }
                }
                return Clients;
            },
            TimeSpan.FromMinutes(60));

            return result;
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new List<GetRegisteredClientsDTO>();
            }
        }

    }
}
