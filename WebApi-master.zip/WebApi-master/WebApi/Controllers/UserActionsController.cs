﻿using Microsoft.AspNetCore.Mvc;
using WebApi.Logic.ControllerLogic.interfaces;
using WebApi.Logic.GenerateToken.interfaces;
using WebApi.Logic.Logging.Interfaces;
using WebApi.Models.RequestObjects;
using WebApi.Models.ResponseObjects;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserActionsController : ControllerBase
    {
        private readonly IUserLogic _userLogic;
        private readonly ITokenHelper _tokenHelper;
        private readonly IImagesLogic _imagesLogic;
        private readonly ILoggerHelper _loggerHelper;
        public UserActionsController(IUserLogic userLogic, ITokenHelper tokenHelper, IImagesLogic imagesLogic, ILoggerHelper loggerHelper)
        {
            _userLogic = userLogic;
            _tokenHelper = tokenHelper;
            _imagesLogic = imagesLogic;
            _loggerHelper = loggerHelper;
        }

        [HttpPost]
        [Route("CreateUser")]
        public async Task<ClientResponseDTO> CreateUser([FromBody] AddClientRequestDTO UserInfo)
        {
            try
            {
                return await _userLogic.CreateUser(UserInfo);
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new ClientResponseDTO();
            }
        }

        [HttpPost]
        [Route("LoginUser")]
        public async Task<LoginUserResponseDTO> AuthenticateUser([FromBody] LoginUserRequestDTO UserCreds)
        {
            try
            {
                return await _userLogic.LoginUser(UserCreds);
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new LoginUserResponseDTO();
            }
        }

        [HttpPost]
        [Route("UploadImages")]
        public async Task<ClientResponseDTO?> UploadImages([FromBody] ImageUploadRequestDTO request)
        {
            try
            {

                if (request?.Images?.Count > 0)
                {
                    return null;
                }

                HttpContext.Request.Headers.TryGetValue("Token", out var Token);

                string clientID = await _userLogic.GetValueFromToken(Token);

                request.ClientId = clientID;

                var result = await _userLogic.UploadImages(request);

                return result;
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new ClientResponseDTO();
            }
        }

        [HttpGet]
        [Route("GetProfileDetails")]
        public async Task<GetProfileDetailsByClientDTO> GetProfileDetailsByClient(Guid ClientID)
        {
            try
            {
                return await _userLogic.GetProfileDetailsByClient(ClientID);
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new GetProfileDetailsByClientDTO();
            }
        }

        [HttpGet]
        [Route("GetUserDetails")]
        public async Task<GetProfileDetailsByClientDTO> GetUserDetails()
        {
            try
            {
                HttpContext.Request.Headers.TryGetValue("Token", out var Token);

                string clientID = await _userLogic.GetValueFromToken(Token);

                _ = Guid.TryParse(clientID, out Guid ClientID);

                return await _userLogic.GetProfileDetailsByClient(ClientID);
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new GetProfileDetailsByClientDTO();
            }
        }

        [HttpGet]
        [Route("GetClientPictures")]
        public async Task<List<string>> GetClientPictures()
        {
            try
            {
                HttpContext.Request.Headers.TryGetValue("Token", out var Token);

                string clientID = await _userLogic.GetValueFromToken(Token);

                _ = Guid.TryParse(clientID, out Guid ClientID);

                return await _imagesLogic.GetAllPicturesPerClient(ClientID);
            }
            catch (Exception ex)
            {
                _loggerHelper.LogDebug(ex.Message);
                return new List<string>();
            }
        }

    }
}
