using WebApi.Logic.Exceptions;
using WebApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.SetupSwagger();
builder.Services.SetupAuthentication(builder.Configuration);
builder.Services.AddMemoryCache();
builder.Services.AddSingleTonServices();
builder.Services.AddScopedServices();
builder.Services.AddCORS();
builder.Services.AddFluentValidation();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors();
app.UseAuthorization();
app.UseMiddleware<ErrorHandler>();
app.MapControllers();

app.Run();
