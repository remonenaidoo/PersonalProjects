﻿using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;
using WebApi.Logic.Caching;
using WebApi.Logic.Caching.interfaces;
using WebApi.Logic.ControllerLogic;
using WebApi.Logic.ControllerLogic.interfaces;
using WebApi.Logic.DataAccess.Database;
using WebApi.Logic.DataAccess.Database.Interfaces;
using WebApi.Logic.DataAccess.Repository;
using WebApi.Logic.DataAccess.Repository.Interfaces;
using WebApi.Logic.Exceptions;
using WebApi.Logic.Exceptions.Interfaces;
using WebApi.Logic.FluentValidation;
using WebApi.Logic.GenerateToken;
using WebApi.Logic.GenerateToken.interfaces;
using WebApi.Logic.Logging;
using WebApi.Logic.Logging.Interfaces;

namespace WebApi.Services
{
    public static class ServicesConfiguration
    {
        public static void AddSingleTonServices(this IServiceCollection services)
        {
            services.AddSingleton<IDbContext, DbContext>();
            services.AddSingleton<IMemoryCachingService, MemoryCachingService>();
        }
        public static void AddScopedServices(this IServiceCollection services)
        {
            services.AddScoped<IUserLogic, UserLogic>();
            services.AddScoped<IRepositoryWrapper, RepositoryWrapper>();
            services.AddScoped<ITokenHelper, TokenHelper>();
            services.AddScoped<ILocationLogic, LocationLogic>();
            services.AddScoped<IImagesLogic, ImagesLogic>();
            services.AddScoped<ILoggerHelper, LoggerHelper>();
            services.AddScoped<IErrorResponses, ErrorResponses>();
        }
        public static void SetupSwagger(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                          new OpenApiSecurityScheme
                            {
                                Reference = new OpenApiReference
                                {
                                    Type = ReferenceType.SecurityScheme,
                                    Id = "Bearer"
                                }
                            },
                            new string[] {}
                    }
                });
            });
        }
        public static void SetupAuthentication(this IServiceCollection services, IConfiguration Configuration)
        {
            services.AddAuthentication(option =>
            {
                option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

            }).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ValidateLifetime = false,
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"])) //Configuration["JwtToken:SecretKey"]
                };
            });
        }
        public static void AddCORS(this IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddDefaultPolicy(builder =>
                {
                    builder.AllowAnyOrigin()
                           .AllowAnyMethod()
                           .AllowAnyHeader();
                });
            });
        }
        public static void AddFluentValidation(this IServiceCollection services)
        {
            #pragma warning disable 618
            services.AddFluentValidation(s =>
            {
                s.RegisterValidatorsFromAssemblyContaining<AuthenticateUserValidator>();
            });
            #pragma warning restore 618
        }

    }
}
